'''
Default configurations.
'''

configs = {
    'debug':True,
    'db':{
        'host':'192.168.181.129',
        'port':3306,
        'user':'root',
        'password':'zjbaaa',
        'db':'awesome'
    },
    'session':{
        'secret':'Awesome'
    }
}