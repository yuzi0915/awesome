import os ,sys,time,subprocess
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHander